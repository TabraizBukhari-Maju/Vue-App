<script>
export default {
  data() {
    return {
      items: [
        { id: 12, name: "서로를 더 사랑하게 만드는 발리&라부안바조", visible: true, date: "2024년 3월 1일" },
        { id: 11, name: "일본 소도시", visible: false, date: "2024년 3월 1일" },
        { id: 10, name: "호주 프레이저 아일랜드", visible: true, date: "2024년 3월 1일" },
        { id: 10, name: "호주 프레이저 아일랜드", visible: true, date: "2024년 3월 1일" },
        { id: 10, name: "호주 프레이저 아일랜드", visible: true, date: "2024년 3월 1일" },
        // ...add more data as per your requirement
      ],
      totalPages: [1, 2, 3, 4, 5]
    };
  }
};
</script>
<style scoped>
.switch {
  position: relative;
  display: inline-block;
  width: 34px;
  height: 20px;
}
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  transition: 0.4s;
}
.slider:before {
  position: absolute;
  content: "";
  height: 12px;
  width: 12px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  transition: 0.4s;
}
input:checked + .slider {
  background-color: #2196f3;
}
input:checked + .slider:before {
  transform: translateX(14px);
}
.slider.round {
  border-radius: 20px;
}
.slider.round:before {
  border-radius: 50%;
}
</style>


<template>
    <div class="p-8">
      <div class="overflow-x-auto">
        <table class="min-w-full bg-white">
          <!-- Table Head -->
          <thead class="text-sm leading-normal text-gray-600 uppercase bg-gray-100">
            <tr>
              <th class="px-6 py-3 text-left">#</th>
              <th class="px-6 py-3 text-left">여행명</th>
              <th class="px-6 py-3 text-center">공개</th>
              <th class="px-6 py-3 text-center">등록일</th>
              <th class="px-6 py-3 text-center">설정</th>
            </tr>
          </thead>
  
          <!-- Table Body -->
          <tbody class="text-sm font-light text-gray-600">
            <tr v-for="(item, index) in items" :key="index" class="border-b border-gray-200 hover:bg-gray-100">
              <td class="px-6 py-3 text-left">{{ item.id }}</td>
              <td class="px-6 py-3 text-left">{{ item.name }}</td>
              <td class="px-6 py-3 text-center">
                <label class="switch">
                  <input type="checkbox" v-model="item.visible" />
                  <span class="slider round"></span>
                </label>
              </td>
              <td class="px-6 py-3 text-center">{{ item.date }}</td>
              <td class="px-6 py-3 text-center">
                <div class="flex justify-center space-x-2 item-center">
                  <button class="text-blue-500 bg-white hover:underline">복사</button>
                  <button class="text-blue-500 bg-white hover:underline">수정</button>
                  <button class="text-blue-500 bg-white hover:underline">이미지관리</button>
                  <button class="text-red-500 bg-white hover:underline">삭제</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
  
      <!-- Pagination -->
      <div class="flex justify-center mt-4">
        <nav class="inline-flex space-x-2">
          <button v-for="page in totalPages" :key="page" class="px-3 py-2 text-sm text-gray-600 bg-white border rounded">
            {{ page }}
          </button>
        </nav>
      </div>
    </div>
  </template>
  